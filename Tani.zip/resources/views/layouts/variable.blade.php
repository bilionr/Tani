<script>var BASE_URL = "{{ url('') }}"</script>
