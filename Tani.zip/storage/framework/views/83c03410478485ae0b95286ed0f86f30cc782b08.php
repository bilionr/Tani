<script>var BASE_URL = "<?php echo e(url('')); ?>"</script>
<?php /**PATH C:\xampp\E-Commerce_TokoPisang\resources\views/layouts/variable.blade.php ENDPATH**/ ?>