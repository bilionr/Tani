<script>var BASE_URL = "<?php echo e(url('')); ?>"</script>
<?php /**PATH E:\Tani\resources\views/layouts/variable.blade.php ENDPATH**/ ?>