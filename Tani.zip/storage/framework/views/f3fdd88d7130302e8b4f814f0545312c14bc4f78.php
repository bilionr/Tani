
<?php $__env->startSection('body'); ?>
<div class="row justify-content-center auth--content">

    <div class="col-xl-6 col-lg-6 col-md-12">
        <div class="card o-hidden border-0 shadow-lg my-5 auth--box">
            <div class="card-body p-0">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="p-5">
                            <div class="text-center">
                                <h1 class="h4 text-gray-900 mb-4">Registrasi Pembeli </h1>
                            </div>
                            <div id="alert-message"></div>
                            <form class="user" id="register--form">
                                <div class="form-group">
                                    <input type="text" class="form-control form-control-user" autocomplete="new-field" placeholder="Nama" id="register--name">
                                    <small class="text-danger error--name"></small>
                                </div>
                                <div class="form-group">
                                    <input type="email" class="form-control form-control-user" autocomplete="new-field" placeholder="Email" id="register--email">
                                    <small class="text-danger error--email"></small>
                                </div>
                                <div class="form-group">
                                    <input type="text" class="form-control form-control-user" autocomplete="new-field" placeholder="No Telp" id="register--phone">
                                    <small class="text-danger error--phone"></small>
                                </div>
                                <div class="form-group">
                                    <input type="password" class="form-control form-control-user" autocomplete="new-field" placeholder="Password" id="register--password">
                                    <small class="text-danger error--password"></small>
                                </div>
                                <div class="form-group">
                                    <input type="password" class="form-control form-control-user" autocomplete="new-field" placeholder="Konfirmasi Password" id="register--password-confirmation">
                                    <small class="text-danger error--password-confirmation"></small>
                                </div>
                                <button type="submit" class="btn btn-warning btn-user btn-block">
                                    Register
                                </button>
                            </form>
                            <hr>
                            <div class="text-center">
                                Sudah punya akun? <a class="small text-warning" href="<?php echo e(route('auth.login')); ?>">Login</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>

</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('server/auth/register.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.auth.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\E-Commerce_TokoPisang\resources\views/auth/register.blade.php ENDPATH**/ ?>