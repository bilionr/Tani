<script>var BASE_URL = "<?php echo e(url('')); ?>"</script>
<?php /**PATH D:\GitHub\Tani\Tani\resources\views/layouts/variable.blade.php ENDPATH**/ ?>